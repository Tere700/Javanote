package tw.org.iii.teresaaaaapp;

public class Tere06 {

	public static void main(String[] args) {
		boolean b1 = true;
		boolean b2 = false;
		System.out.println(b1);
		System.out.println(b2);				
		//boolean沒有在做運算 布林值在java中1=1 0=0 不代表true or false

	}

}
