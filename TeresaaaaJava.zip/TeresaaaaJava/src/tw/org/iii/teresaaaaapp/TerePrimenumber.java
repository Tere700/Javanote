package tw.org.iii.teresaaaaapp;

public class TerePrimenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
