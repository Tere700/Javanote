package tw.org.iii.teresaaaaapp;

import tw.org.iii.clasees.Bikw;

public class HHU {

	public static void main(String[] args) {

			Bikw b1 = new Bikw();
			b1.upSpeed();b1.upSpeed();b1.upSpeed();b1.upSpeed();		
			System.out.println(b1.getSpeed());
			
	
	}

}
