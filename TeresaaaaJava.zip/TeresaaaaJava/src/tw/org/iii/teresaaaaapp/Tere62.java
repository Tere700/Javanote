package tw.org.iii.teresaaaaapp;

import java.net.InetAddress;

public class Tere62 {

	public static void main(String[] args) {


		InetAddress
	}

}
