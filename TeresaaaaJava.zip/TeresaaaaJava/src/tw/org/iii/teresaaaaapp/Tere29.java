package tw.org.iii.teresaaaaapp;

public class Tere29 {

	public static void main(String[] args) {
		
	}
}
class Tere291{
	Tere291(){
		
	}
	Tere291(int a){
		
	}
	

}
