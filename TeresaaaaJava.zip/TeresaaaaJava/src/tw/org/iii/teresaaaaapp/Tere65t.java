package tw.org.iii.teresaaaaapp;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Tere65t {

	public static void main(String[] args) {
	
		String ur1 = ("dir1/workout.jpg");
				
				
	}

}


