package tw.org.iii.teresaaaaapp;

import tw.org.iii.clasees.Bike;
import tw.org.iii.clasees.Scooter;

public class Tere22 {

	public static void main(String[] args) {

		Bike b1 = new Bike("Tere");

		b1.upSpeed();b1.upSpeed();b1.upSpeed();b1.upSpeed();
		System.out.println(b1.getSpeed());
		

	}}
			

