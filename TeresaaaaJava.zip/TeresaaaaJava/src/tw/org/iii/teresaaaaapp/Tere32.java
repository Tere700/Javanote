package tw.org.iii.teresaaaaapp;

public class Tere32 {

	public static void main(String[] args) { //Static與物件無關
	
	//擴充性別跟地區

	}

}
