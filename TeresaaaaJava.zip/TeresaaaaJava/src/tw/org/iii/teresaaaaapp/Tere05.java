package tw.org.iii.teresaaaaapp;

public class Tere05 {

	public static void main(String[] args) {
		char c1 = 'a';
		System.out.println(c1);
		char c2 = 65;
		System.out.println(c2);
		char c3 = '資';
		System.out.println(c3);
		int a = c1+c2;
		System.out.println(a); //不重要
		
		
				/* 雙引號永遠是字串 不是基本型別
				 * 單引號是字元 一個字元 字元沒有負數 0~65535
				 * ASCII-可顯示/列印字元
				 * Numlock+alt+數字
				 */

	}

}
