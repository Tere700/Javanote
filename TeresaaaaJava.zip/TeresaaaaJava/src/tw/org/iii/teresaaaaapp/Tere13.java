package tw.org.iii.teresaaaaapp;

public class Tere13 {

	public static void main(String[] args) {
		int i=0;
		for (; i<10;printline()) {
			System.out.println(i++);
		}
			System.out.println("Over"+1);
	}
		static void printBrad() {
			System.out.println("BradV3");
		}
		static void printline() {
			System.out.println("--------");
		}
}
//for(一定要被做/只會做一次(初始化);boolean;___){}
//命令列輸出特性:一行印完印下一行 不能回頭