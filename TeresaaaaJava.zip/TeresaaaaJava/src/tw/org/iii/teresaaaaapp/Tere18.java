package tw.org.iii.teresaaaaapp;

public class Tere18 {

	public static void main(String[] args) {
		int a=1;
		while(a < 10) /*括號內是boolean*/{
			System.out.println(a++);//a沒有++會變成無限循環
		
		}
		//1+2+3+....+n=?

	}}
