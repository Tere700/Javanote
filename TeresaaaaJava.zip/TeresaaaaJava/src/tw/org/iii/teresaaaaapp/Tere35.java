package tw.org.iii.teresaaaaapp;

public class Tere35 {

	public static void main(String[] args) {

	}

}
class shape {
	
}