package tw.org.iii.teresaaaaapp;

public class Tere10 {

	public static void main(String[] args) {
		int a=5, b=3; 
		if ( ++a <= 5 || ++b>= 3 ) {
			System.out.printf("OK:a=%d, b=%d, a, b");
		}else {
			System.out.printf("XX:a=%d, b=%d, a,b");
		}

	}

}
