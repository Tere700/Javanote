package tw.org.iii.teresaaaaapp;

public class Tere68 {

	public static void main(String[] args) {
		double a = 10.2;
		System.out.println(Math.floor(a));
		System.out.println(Math.ceil(a));

	}

}
