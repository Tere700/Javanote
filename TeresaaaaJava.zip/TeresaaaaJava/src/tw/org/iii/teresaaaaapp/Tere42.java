package tw.org.iii.teresaaaaapp;

import java.io.File;

public class Tere42 {

	public static void main(String[] args) {
		System.out.println(File.pathSeparator);
		System.out.println(File.separator);

	}

}
