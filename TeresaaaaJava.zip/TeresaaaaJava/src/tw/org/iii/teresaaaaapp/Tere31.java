package tw.org.iii.teresaaaaapp;

public class Tere31 {
			String s1 = "Brad";
			String s2 = s1.concat(iii);
			
			}
			} {
			
			}
}
