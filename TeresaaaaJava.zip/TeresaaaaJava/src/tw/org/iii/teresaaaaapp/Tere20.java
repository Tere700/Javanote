package tw.org.iii.teresaaaaapp;

public class Tere20 {

	public static void main(String[] args) {
		int a = 10, b = 3;
		
//		int c=a;b=a;b=c;
		a= a + b; //a=13,數學才可以
		b= a - b; //b=10
		a= a - b; //a=3
		System.out.printf("a=%d, b=%d", a,b);
	}

}
