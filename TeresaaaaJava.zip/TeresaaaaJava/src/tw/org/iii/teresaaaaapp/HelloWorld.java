package tw.org.iii.teresaaaaapp;
//HelloWorld要跟檔名一致
public class HelloWorld {
	//程式進入點 Java大小寫要明確
	//static指靜態與物件無關 輸出err&out由開發者決定 影響其他程式搭配者
	//in輸入=鍵盤的輸入
	public static void main (String[] args) {
	//相同名稱參數不同 ;{}為結尾方式
	//編譯時期or執行時期犯的錯
	System.out.println("Hello,Tere");
	//print println 差再換列 or \跳脫escape 
	//\n換列→mac&java \r\n→windows "Hello,Tere\n"換列
	System.out.println("HelloWorld");
}
}
