package tw.org.iii.teresaaaaapp;

public class Tere23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
