package tw.org.iii.teresaaaaapp;

public class Tere994 {

	public static void main(String[] args) {

		 for(int k=0;k<2;k++)
			for(int i=1;i<=9;i++) {
				int r=2*i;
		
				System.out.printf("2 x %d = %d\t",i,r);
		
	}}}