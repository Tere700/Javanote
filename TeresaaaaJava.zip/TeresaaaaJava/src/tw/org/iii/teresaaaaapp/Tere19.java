package tw.org.iii.teresaaaaapp;

public class Tere19 {

	public static void main(String[] args) {
		int a = 1;
		do {
			System.out.println(a++); //後側迴圈 先做再說 至少做一次
		} while(a<10);

	}

}
