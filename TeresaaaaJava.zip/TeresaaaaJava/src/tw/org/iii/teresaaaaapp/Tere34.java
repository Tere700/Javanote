package tw.org.iii.teresaaaaapp;

public class Tere34 {

	public static void main(String[] args) {
	
	}
abstract class Tere341{
	void m1() {System.out.println("Brad341:m1()");}
	void m2() {System.out.println("Brad341:m2()");}
}
}
