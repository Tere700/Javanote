package tw.org.iii.teresaaaaapp;

public class Tere04 {

	public static void main(String[] args) {
		float var1 = 10.123456789f; //f表示我是float 沒寫f一般預設為double
		double var2 = 10.123456789;
		System.out.println(var1);
		System.out.println(var2);
		
		double a=10;
		double b=0; //NaN-not a number
		System.out.println(a/b);
		
		
		/*float=2的32次方 精確度低
		 *double=2的64次方 精確度高
		 *在比精確度
		 *IEEE浮點運算
		 *節省記憶體空間
		 *Java virtual machine = JVM, byte code
		 */

	}

}
