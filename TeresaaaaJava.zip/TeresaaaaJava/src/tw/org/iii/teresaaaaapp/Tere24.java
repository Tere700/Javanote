package tw.org.iii.teresaaaaapp;

import javax.swing.JFrame;

public class Tere24 extends JFrame {
	public Tere24() {
		super("我的視窗");
		
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		new Tere24();

	}

}
