package tw.org.iii.clasees;

public interface Tere37interface {
	void m1();//所有東西都是public
}
